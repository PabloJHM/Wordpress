        <?php get_header();
/************************************************/
        define('WP_DEBUG',true);
        define('WP_DEBUG_LOG',true);
/************************************************/
        ?>
<body>
    <!-- Navigation -->
    

    <!-- Page Content -->
    <div class="container">

        <!-- Jumbotron Header -->
        <header class="jumbotron hero-spacer">
            <div class="jum">
                <h1>Bienvenidos a Travelin</h1>
                <p>Disfruta de nuestras ofertas y paquetes de viajes por un precio unico!</p>
            </div>
<!--
            <p><a class="btn btn-primary btn-large">Call to action!</a>
            </p>
-->
        </header>
        <!-- Title -->
        <div class="row">
            <div class="col-lg-12">
                <h3>Ultimas novedades</h3>
            </div>
        </div>
        <!-- /.row -->

        <!-- Page Features -->
        <div class="row text-center">
            <?php
            $args=array(
                'showposts'=>6,
                'tax_query' =>array(
                                array(
                                    'taxonomy'=> 'post_format',
                                    'field'=>'slug',
                                                'terms' => array('post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),
                                    'operator'=>'NOT IN')
                            ),
                        );
            $custom=new WP_Query($args);
            if($custom->have_posts()):while($custom->have_posts()):$custom->the_post();?>
            <div class="col-md-4 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <a href="<?php the_permalink();?>">
                        <?php 
                        if(has_post_thumbnail()){?>
                        <figure>
                            <?php the_post_thumbnail('full',array('class'=>'thum'));?>
                            <figcaption class="thumCapt"><?php the_title();?></figcaption>
                        </figure>
                    <?php } else {?>
                        <figure>
                            <img src="<?php echo get_template_directory_uri()?>/img/icono.png" class="thum"  alt="zepelin">
                            <figcaption class="thumCapt"><?php the_title();?></figcaption>
                        </figure> 
                       <?php }?>
                    </a>
<!--                    <a href="<?php the_permalink();?>"><h4><?php the_title();?></h4></a>-->
                    <?php the_category(', ');?>
                    <p>Por: <?php the_author_posts_link(); ?>, el <?php the_time('Y-M-D'); ?> </p>
                </div>
            </div>    
            <?php endwhile;
            endif;
            wp_reset_query();
            ?>
        </div>
    </div>
        <?php get_footer();?>

