<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="post-gallery">
                <a href="<?php the_permalink(); ?>"><h3><?php the_title();?></h3></a>
                <p>Por: <?php the_author(); ?>, el <?php the_time(); ?> </p>
                <?php the_content();?>
            </div>
        </div>
    </div>
</div>