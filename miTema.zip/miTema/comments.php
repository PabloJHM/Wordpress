<div id="comments">
    <ul><?php 
    $args = array(
        'style'=>'ol',
        'avatar_size'=>64,
        'format'=>'html5',
        'type'=>'all',//[all/comment/trackback/pingback/pings]
        'reply_text'=>'Reply',
        'per_page'=>10
        );
//    $comments=get_comment(array(
//        'status'=>'aprove'
//    ));
    wp_list_comments();?></ul>
</div>
<div id="respond">
    <?php comment_form();?>
</div>