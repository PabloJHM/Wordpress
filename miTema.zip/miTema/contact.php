<?php
    /*
    Template Name: Contact
    */
    get_header();?>
<body>
    <div class="contacta">
        <h1 class="conth1">Contacta con nosotros</h1>
        <h3 class="conth3">¿Tienes dudas? ¿Necesitas asesoramiento?</h3><br>
        <h4 class="conth4">Sea cual sea su duda puede ponerse en contacto con nosotros escribiendo un email a </h4>
        <h3>travellin@gmail.com</h3>
        <h4>y resolveremos tus dudas tan pronto como nos sea posible.</h4>
        <h4>También puede realizar preguntas en los comentarios de los posts.</h4>
        <h4>Nuestro equipo está pendiente de lo que escriben nuestros usuarios.</h4> 
        <h4>Vuestras opiniones y dudas nos importan.</h4>
    </div>
</body>
<?php get_footer();?>
