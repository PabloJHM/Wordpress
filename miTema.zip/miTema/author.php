<?php get_header();
$curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));

?>
<body>
    <div class="container">
        <div class="col-lg-2 cd-md-4 col-xs-8 author">
            <div class="autImg">
            <?php 
                    if(has_gravatar($curauth->user_email)){
                        echo get_avatar($curauth->user_email,300);
                    } else {
                        $miURL=get_template_directory_uri()."/img/".$curauth->nickname.".jpg";
                        if(file_exists(TEMPLATEPATH.'/img/'.$curauth->nickname.".jpg")){
                            echo '<img src="'.$miURL.'" class="img-responsive">';
                        } else {
                            echo '<img src="'.get_template_directory_uri().'/img/nopic.png" class="img-responsive">';
                        }
            }?>
            </div>
        </div>
        <div class="col-lg-10 cd-md-4 col-xs-8 author">
            <div class="bio">
                <h2><?php echo $curauth->nickname?></h2>
                <p><b>| Nombre:</b>
                <?php   if(!empty($curauth->first_name)){
                            echo $curauth->first_name.' | ';
                        } 
                        if (!empty($curauth->last_name)){
                            echo $curauth->last_name.' | ';
                        }
                        if(!empty($curauth->user_email)){
                            echo '<b>Email:</b> '. $curauth->user_email.' | ';
                        }
                        if(!empty($curauth->facebook)){
                            echo '<b>FaceBook:</b> '. $curauth->facebook.' | ';
                        }
                        if(!empty($curauth->twitter)){
                            echo '<b>Email:</b> '. $curauth->twitter.' | ';
                        }
                    ?>
                </p>
                <p><?php echo get_the_author_meta(description).'<br/>';?></p>
            </div>
        </div>
    </div>
    <div class="postsAut">
        <div class="container">
            <h2>Entradas de este usuario: </h2>
            <?php
                        $args = array(
                            'showposts'=>-1,
                            'post_type' =>'post',
                            'post__not_in'=>array($id_post_des),
                            'author' => $curauth->ID,
                            'tax_query' =>array(
                                array(
                                    'taxonomy'=> 'post_format',
                                    'field'=>'slug',
                                    'posts_per_page' => -1,
                                    'terms'=>array('post-format-aside','post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),'operator'=>'NOT IN') 
                            ),
                        );
                        $the_query=new WP_Query($args);
                        $par=1;
                        if($the_query->have_posts()):while($the_query->have_posts()):$the_query->the_post();
                                get_template_part('content',get_post_format());
                            endwhile;
                        endif;
                    ?>
            
        </div>
    </div>
<?php get_footer();?>