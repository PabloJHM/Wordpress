<?php get_header(); ?>
<figure class="banner">
    <div class="contCabecera">
        <h2>Travelin</h2>
        <h3>Viajes por todo el mundo</h3>
    </div>
</figure>
<div class="container">
    <div class="row">
        <div class="col-lg-8 cd-md-8 col-xs-12">
            <?php 
                the_post();
            ?>
            <p><?php the_category(', '); ?>, <?php comments_number('Ningun comentario','Un comentario','% comentarios')?></p>
            <h1><?php the_title(); ?></h1>
            <p class="tags">Posted by: <?php the_author_posts_link();  ?> on <?php the_time('d F, Y');?></p>
            <?php 
                $content = get_the_content();
                //para comprobar si es una galeria
                if(strpos($content, '[gallery')!== false) {
                    the_content();
                } else {
                $content=preg_replace('/<img class="/','<img class="img-responsive ',$content);
                echo $content;
                }
            ?>   
            <div class="pagPost">
                <?php 
                wp_link_pages(array(
                'before'=>'<div class="post-pages">Pages: ',
                'after'=>'</div>',
                ));?>
            </div>
            <p class="tags"><?php the_tags(' ',' ',' '); ?></p>
            <br/><br/>
            <?php previous_post_link();?>
            <?php next_post_link();?>
            <hr/>
            <?php
            if(comments_open()){
                comments_template();
            } else {
                echo 'los comentarios estan desahabilitados';
            }
            ?>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-12">
            <?php get_sidebar('sidebar');?>
        <!-- Va a buscar en nuestra plantilla una pagina llamada 'sidebar.php'. Si no existe va a cargar por defeco la plantilla de wordpress. Podemos tener varias sidebar-->
        </div>
    </div>
</div>

<?php get_footer(); ?>
