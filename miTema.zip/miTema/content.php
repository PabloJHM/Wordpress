<?php 
if($par==2){?>
    <div class="elementolistaizq">
<?php 
} elseif($par==1) {?>
    <div class="elementolistader">
<?php 
} else {?>
    <div class="elementolistacen">
<?php }?>
    <a href="<?php the_permalink();?>"><?php 
    if(has_post_thumbnail()){
        the_post_thumbnail('full',array('class'=>'otras hvr-grow'));
    } else {?>
        <img src="<?php echo get_template_directory_uri()?>/img/icono.png" class="otras hvr-grow"  alt="zepelin">
<?php }?></a>
        <div class="otrasnoticias">
        <a href="<?php the_permalink();?>"><h3><?php the_title();?></h3></a>
        <?php the_category(', ');?>
        <p>Por: <?php the_author_posts_link(); ?>, el <?php the_time(); ?> </p>
        <br/>
    </div>
</div>
