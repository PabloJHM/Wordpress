
<!-- Footer -->
    <footer>
        <br>
        <div class="footer">
            <div class="row">
                <div class="col-lg-4">
                    <h4 class="footh4">Paginas</h4>
                    <div class="footlistaPag">
                        <?php wp_list_pages(array('title_li' => ''));?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h4 class="footh42">Contactanos</h4>
                    <div class="footcontacta">
                        <p>Correo: travellin@gmail.com</p>
                        <p>Tlf: 647 59 77 46</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h4 class="footh42">Categorias</h4>
                    <div class="footcategorias">
                    <?php wp_list_categories(array('title_li'=>""));?>
                        </div>
                </div>
            </div>
            <p class="footp">Copyright &copy; Travellin 2016</p>

        </div>
    </body>
<!------------------------------------------------------------------------------------ -->
        <?php 
        $url=$_SERVER["REQUEST_URI"]; 
        if(strpos($url, "plerti")!==false){?>
                <script type='text/javascript' src='http://www.adhamdannaway.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
        <script type='text/javascript' src='http://www.adhamdannaway.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.0.2'></script>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> 
        <script>window.jQuery || document.write('<script src="js/jquery-1.7.2.min.js"><\/script>')</script> 
        <script src="http://www.adhamdannaway.com/wp-content/themes/ad/js/script.js"></script>
        <script type="text/javascript">
        <!--

        //If browser is IE8 or older we show IE specific page
        if(ie < 9){
            ieMessage();
        }

        /*
        * Call functions when dom is ready
        */
        $(document).ready(function() {

            // Hide browser top bar in mobiles
            $('body').scrollTop(1);

            // Toggle Navigation for mobile devices
            $('.icon-nav').on('click', function(){
                $('header nav').slideToggle();
                $(this).toggleClass('active');
            });

            // Function to scroll to top
            $('a[href=#top]').click(function(){

                $('html, body').animate({scrollTop:0}, 1000, 'easeInOutQuad');
                return false;
            });

            // Function to fade in image sprites
            $('.sprite').fadeSprite();

            //Function for thumbnail hover effect
            $('.thumbs li').hoverThumb();

            // Function to animate when leaving page
            $('.transition, #nav a, #nav-footer a, #thumbs a, #next a, #prev a, #logo, #face a').leavePage();	

            // Animate the header on first			
            $('#header').stop().animate({'opacity': '1', 'top':'0'}, 1000);

            // Preload the page with jPreLoader
            $('body').jpreLoader({

                showSplash: true

            }, function() {	

                //Show the page once images are loaded	
                    animateMain();
                    animateAbout();


            });

        });
        -->
        </script>

        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

          ga('create', 'UA-2290797-3', 'adhamdannaway.com');
          ga('send', 'pageview');

        </script>
    </footer>
    <!-- Bootstrap Core JavaScript -->
<!--    <script src="<?php /*bloginfo('template_url');*/?>/js/bootstrap.min.js"></script>-->
    <?php } wp_footer();?><!--Hook-->
</html>
