
        <?php get_header();
/************************************************/
        define('WP_DEBUG',true);
        define('WP_DEBUG_LOG',true);
/************************************************/
        ?>
<body>
<header class="post_destacado" style="background-image:url('')">
    <div class="principal">
        <?php 
            $url=$_SERVER["REQUEST_URI"] ;
//            if(strpos($url, 'category') !== false){
//                $pos=strpos($url,'category/')+9;
//                $cat= str_replace("/","",substr($url,$pos));
//                $idObj=get_category_by_slug( $cat );
//                
//                $id = $idObj->cat_ID;
//            }
            $semaforo=false;
            $args=array(
                'tax_query' =>array(
                                array(
                                    'taxonomy'=> 'post_format',
                                    'field'=>'slug',
                                                'terms' => array('post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),
                                    'operator'=>'NOT IN')
                            ),
                        );
        $the_query=new WP_Query($args);
        if($the_query->have_posts()):while($the_query->have_posts()):$the_query->the_post();
            the_post();
            $format = get_post_format() ? : 'standard';
            if($format=='standard' && $semaforo==false){
            $id_post_des=$post->ID;
            $semaforo=true;
        ?>
        <?php if(has_post_thumbnail()){?>
            <figure class="figfondo">
                <?php the_post_thumbnail('full',array('class'=>'imgfondo'));?>
            </figure>
        <?php } else {?>
            <figure class="figfondo">
                <img src="<?php echo get_template_directory_uri()?>/img/sinthumbnail.png" class="imgfondo"  alt="zepelin">
            </figure>
        <?php }?>
        <div class="datos">
            <a href="<?php the_permalink(); ?>"><h1><?php the_title();?></h1></a>
                <p>Autor: <?php the_author();?>, <?php the_time();?></p>
        </div>
        <?php }
        endwhile;
        endif;?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="noticias">
                    
                    <?php
                        //Excluir un ID expecifico del bucle
                        /*OJO CON EL DOBLE GUION BAJO*/
                        $args = array(
                            'showposts'=>-1,
                            'post_type' =>'post',
                            'post__not_in'=>array($id_post_des),
                            'tax_query' =>array(
//                                'relation' => 'OR',
                                array(
                                    'taxonomy'=> 'post_format',
                                    'field'=>'slug',
                                    'terms'=>array('post-format-aside', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),'operator'=>'NOT IN')  //'post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'
                            ),
                        );
                        $the_query=new WP_Query($args);
                        $par=1;
                        if($the_query->have_posts()):while($the_query->have_posts()):$the_query->the_post();
                            $format = get_post_format() ? : 'standard';
                            //Compruebo el formato del post. Si es standard llamo a content.php a traves de include para poder pasarle el semaforo y asi conseguir el efecto de alternar entre der/izq, si no es standard llamo a su correspondiente content con template part
                                if($format=='standard'){
                                    include(locate_template('content.php'));
                                    if($par==1){$par=2;}else{$par=1;}
                                } else {
                                    get_template_part('content',get_post_format());
                                }
                        endwhile;
                    endif;?>
                </div>
            </div>
        </div>
    </div>
    </header>
    <?php get_footer();?>
<!--array(
                                'relation'=>'AND',
                                array(
                                    'taxonomy'=> 'category',
                                    'field'=>'slug',
                                    'terms'=>array('post-format-quote')
                                ),
                                array(
                                    'taxonomy'=> 'category',
                                    'field'=>'slug',
                                    'terms'=>array('')
                                ),
                            ),*/-->