<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="post-link">
                <span class="author-link"><?php the_author()?> @ <?php the_time('j F Y')?></span>
                <br/>
                <a href="<?php echo get_the_content();?>"/>
                <h3><?php echo get_the_title();?></h3>
            </div>
        </div>
    </div>
</div>