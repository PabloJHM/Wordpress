<?php 
    /*Template Name: Archives*/
    get_header();?>
<body>
    <div class="container">
        <div class="col-lg-4 cd-md-4 col-xs-8 izquierda">
            Ordenar por:
                        <!-- para visualizar una lista de los archivos ordenados por año y cuantos hay de ese año:-->

            <?php wp_get_archives('type=yearly&show_post_count=1'); ?>
            <?php wp_get_archives('type=monthly&show_post_count=1'); ?>
            <?php wp_get_archives('type=daily&show_post_count=1'); ?>
            <?php ?>
        </div>  
        <div class="col-lg-4 cd-md-4 col-xs-8 centro">
            <?php get_search_form();?>
            <?php wp_list_authors('show_fullname=1&optioncount=1&hide_empty=0');?>
            <?php wp_list_categories('show_count=1');?>
            <?php get_the_tag_list(' ', ' ', ' ');?>
            
<!--
            
            <-?php wp_list_pages();?>
            <-?php wp_list_bookmarks();?>
            <-?php wp_list_comments();?>
            <-?php wp_tag_cloud();?>
-->
        </div>  
        <div class="col-lg-4 cd-md-4 col-xs-8 derecha">
            <?php get_sidebar('archives'); ?>
        </div>  
    </div>
<?php get_footer();?>