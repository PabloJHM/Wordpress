<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Archives Widgets')) :?>
        <!-- Lo que haya aquí se mostrará en caso de que no existan widgets. En caso de que existan widgets, utilizarán este espacio -->
        Hola
<?php endif?>