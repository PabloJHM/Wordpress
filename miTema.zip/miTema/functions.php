<?php
add_theme_support('html5');
add_theme_support('post-formats',array('aside','link','gallery'));
add_filter('use_default_gallery_style','__return_false');
function nombre_que_quiera_jquery(){
    //Registrar el script
    wp_register_script('custom-script', get_template_directory_uri().'/js/bootstrap.js', array('jquery'));
    wp_enqueue_script('custom-script');
}
add_action('wp_enqueue_scripts', 'nombre_que_quiera_jquery' );
add_theme_support('post-thumbnails');

function limpiaArrays($cadena){
        $quitamos=array('/\./','/\,/','/\-/','/\_/','/\:/','/\;/');
        $search_words=preg_replace($quitamos,' ',$cadena);
        $lista_words=explode(' ',$search_words);
        $lista_words=array_filter($lista_words);
        $s=implode($lista_words, ' ');
        return $s;
    }   

//Activar el area de widgets
if(function_exists('register_sidebar')){
    register_sidebar(array(
    'name'=>'Sidebar Widgets',
    'before_widget'=>'<div id="%1$s" class="widget %2$s">',
    'after_widget'=>'</div>',
    'before_title'=>'<h4 class="widgettitle">',
    'after_title'=>'</h4>'));
}

if(function_exists('register_sidebar')){
    register_sidebar(array(
    'name'=>'Archives Widgets',
    'before_widget'=>'<div id="%1$s" class="widget %2$s">',
    'after_widget'=>'</div><br/>',
    'before_title'=>'<h4 class="widgettitle">',
    'after_title'=>'</h4>'));
}

//Comrpueba si existe gravatar
function has_gravatar($email) {
	// Craft a potential url and test its headers
	$hash = md5(strtolower(trim($email)));
	$uri = 'http://www.gravatar.com/avatar/' . $hash . '?d=404';
	$headers = @get_headers($uri);
	if (!preg_match("|200|", $headers[0])) {
		$has_valid_avatar = FALSE;
	} else {
		$has_valid_avatar = TRUE;
	}
	return $has_valid_avatar;
}

function extra_profile_fields($user){?>
<h3>Extra profile information</h3>
<table class="form-table">
    <tr>
        <th><label for="twitter">Twitter</label></th>
        <td>
            <input type="text" name="twitter" id="twitter" value="<?php echo esc_attr(get_the_author_meta('twitter',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter your Twitter username.</span>
        </td>
    </tr>
    <tr>
        <th>
            <label for="facebook">Facebook</label></th>
        <td><input type="text" name="facebook" id="facebook" value="<?php echo esc_attr(get_the_author_meta('facebook',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter your Facebook username.</span>
        </td>
    </tr>
    <tr>
        <th>
            <label for="java">Java</label></th>
        <td><input type="number" name="java" id="java" value="<?php echo esc_attr(get_the_author_meta('java',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter an overall percentage of your skill in Java</span>
        </td>
    </tr>
    <tr>
        <th>
            <label for="php">PHP</label></th>
        <td><input type="number" name="php" id="php" value="<?php echo esc_attr(get_the_author_meta('php',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter an overall percentage of your skill in PHP</span>
        </td>
    </tr>
    <tr>
        <th>
            <label for="wp">Wordpress</label></th>
        <td><input type="number" name="wp" id="wp" value="<?php echo esc_attr(get_the_author_meta('wp',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter an overall percentage of your skill in Wordpress</span>
        </td>
    </tr>
    <tr>
        <th>
            <label for="htmlcss">HTML &amp; CSS</label></th>
        <td><input type="number" name="htmlcss" id="htmlcss" value="<?php echo esc_attr(get_the_author_meta('htmlcss',$user->ID));?>" class="regulra-text"/> <br/>
            <span class="description">Please enter an overall percentage of your skill in Html and Css</span>
        </td>
    </tr>
</table>    
<?php }
add_action('show_user_profile','extra_profile_fields');
add_action('edit_user_profile','extra_profile_fields');?>


<?php 
    function save_extra_profile_fields($user_id){
        if(!current_user_can('edit_user', $user_id)) //Comprobamos si es el usuario activo, si no, ni se mostrarán y no podrá verlo nadie, ni el admin
            return false;
        update_usermeta($user_id, 'facebook', $_POST['facebook']);
        update_usermeta($user_id, 'twitter', $_POST['twitter']);
        update_usermeta($user_id, 'java', $_POST['java']);
        update_usermeta($user_id, 'php', $_POST['php']);
        update_usermeta($user_id, 'wp', $_POST['wp']);
        update_usermeta($user_id, 'htmlcss', $_POST['htmlcss']);
    }
add_action('personal_options_update','save_extra_profile_fields');
add_action('edit_user_profile','save_extra_profile_fields');
the_author_meta('facebook',$curauth->ID);
the_author_meta('twitter',$curauth->ID);
the_author_meta('java',$curauth->ID);
the_author_meta('php',$curauth->ID);
the_author_meta('wp',$curauth->ID);
the_author_meta('htmlcss',$curauth->ID);


?>

