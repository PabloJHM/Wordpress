<?php get_header();?>

<!-- Los estilos que usa esta plantilla entran en conflicto con los mios, provocando asi que tanto el header como el footer se vean distintos. He intentado modificarlos pero no he tenido exito, aun cuando el resto de cosas que hay en la pagina si puedo cambiarles los estilos sobreescribiendolos con los mios-->

<!-- HTML5 Boilerplate -->
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html class="no-js lt-ie9 lt-ie8" lang="en"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html class="no-js lt-ie9" lang="en"><![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"><!--<![endif]-->
<!--	-->
	<link rel="stylesheet" type="text/css" href="http://www.adhamdannaway.com/wp-content/themes/ad/style.css">
	<link rel="stylesheet" type="text/css" href="style.css">
<!-- Hace que no aparezcan las cosas antes de su animacion-->
	<script src="http://www.adhamdannaway.com/wp-content/themes/ad/js/modernizr-2.5.3-min.js"></script>
    <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js?ver=4.0.8'></script>
    <style type="text/css" id="syntaxhighlighteranchor"></style>

<body class="clearfix">
    
<!-- Tengo que dejar este enlace porque es necesario para que salgan las animaciones -->
<a id="snaps-6" target="_blank"></a>

<?php 
    $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
?>
	<div class="content clearfix">
		<section class="main">
			<div class="row">
				<div id="text-main" class="col-5 text-main">
                    <div class="nombreAdmin">
                        <h1><?php echo $curauth->nickname?></h1>
                    </div>
					<h2>Sobre mi:</h2>
                    <p class="intro"><?php  echo get_the_author_meta(description); ?></p>
				</div>
				<div id="img-main" class="col-7 align-r">
                    <div class="imgavatarAdmin">
					<?php 
                    if(has_gravatar($curauth->user_email)){
                        echo get_avatar($curauth->user_email,300);
                    } else {
                        $miURL=get_template_directory_uri()."/img/".$curauth->nickname.".jpg";
                        if(file_exists(TEMPLATEPATH.'/img/'.$curauth->nickname.".jpg")){
                            echo '<img src="'.$miURL.'" class="img-admin">';
                        } else {
                            echo '<img src="'.get_template_directory_uri().'/img/nopic.png">';
                        }
                    }?>
                        
				</div>
			</div>
        </section>
        <section class="dark">			
                            <h2>Mis enlaces: </h2>

            <div id="snaps" class="row align-c snaps clearfix">
                <?php 
                if(!empty($curauth->facebook)){?>
                    <a id="snaps-1" target="_blank" class="enlaceAdmin" href="<?php echo $curauth->facebook?>">Facebook</a>
                <?php    }
                if(!empty($curauth->twitter)){?>
                    <a id="snaps-2" target="_blank" class="enlaceAdmin" href="<?php echo $curauth->twitter?>">Twitter</a>
                <?php }?>
			</div>
		</section>

		<div id="content-detail">
			<section class="light nopad-b">
                <div class="row">
					<div  class="col-12">
                       <h2 class="align-l">My technical skills</h2>
                       <div class="knob">
                         <?php 
                            $pruebabarras=
                            '[skillwrapper type="circle" track_color="#bbbbbb" chart_color="#333333" chart_size="150" align="center"]
                            [skill percent="'.$curauth->java.'" title="Java"]
                            [skill percent="'.$curauth->php.'" title="PHP"]
                            [skill percent="'.$curauth->wp.'" title="Wordpress"]
                            [skill percent="'.$curauth->htmlcss.'" title="Html&Css"]
                            [/skillwrapper]'; 
                         echo do_shortcode($pruebabarras, $ignore_html = false)?>
                        </div>
					</div>
				</div>
			</section>

			<section class="dark nopad-b">
				<div class="row alt">
					<div class="col-5 ten-things text-middle">
						<h2>Random facts</h2>
						<ul class="ul">
							<li>Soy un pedazo friki.</li>
							<li>Me gusta jugar a Yu-Gi-Oh!</li>
							<li>Puedo comerme una caja entera de pastelitos en un dia.</li>
							<li>Quiero desarrollar un videojuego.</li>
							<li>Me gustaria viajar a japon.</li>
							<li>Me encanta escuchar musica.</li>
							<li>Tengo un gato.</li>
						</ul>
					</div>
					<div id="img-1" class="col-7 align-c">
						<img class="major" src="http://www.adhamdannaway.com/wp-content/themes/ad/images/yoda.jpg" alt="Yoda rocks">
					</div>
				</div>
			</section>
			<section class="light">
				<div class="row">
						<h2>Mis posts</h2>
						<?php
                        $args = array(
                            'showposts'=>-1,
                            'post_type' =>'post',
                            'author' => 1,
                            'post__not_in'=>array($id_post_des),
                            'tax_query' =>array(
                                array(
                                    'taxonomy'=> 'post_format',
                                    'field'=>'slug',
                                    'posts_per_page' => -1,
                                    'terms'=>array('post-format-aside','post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),'operator'=>'NOT IN') 
                            ),
                        );
                        $the_query=new WP_Query($args);
                        $par=1;
                        if($the_query->have_posts()):while($the_query->have_posts()):$the_query->the_post();
                                get_template_part('content',get_post_format());
                            endwhile;
                        endif;
                    ?>
				</div>
			</section>
		</div>
	</div>
    <?php get_footer();?>

    </div>

