<?php
    /*
    Template name: About
    */
    get_header();?>
<body>
    <div class="container us">
        <div class="aboutUs">
            <div class="col-lg-6 cd-md-4 col-xs-8 izquierdaUs">
                <div class="somos">
                    <h1>¿Quienes somos?</h1>
                    <p>Somos una pequeña compañia de viajes recien salida al mercado. Aun siendo una pequeña empresa nuestro ánimo es justo lo contrario, a la par que nuestras ganas de crecer.</p><br>
                </div><br>
                <div class="segundoZep">
                    <img class="ourship" src="<?php echo get_template_directory_uri()?>/img/ourcompany2.jpg"> 
                </div>
                <div class="politica">
                    <h1>Nuestra politica</h1>
                    <p>Nuestra politica es ofrecer las mejores ofertas de viajes en una relacción calidad-precio superior a cualquier otra compañia de viajes  aparte de, por supuesto, la comodidad y la seguridad de nuestros clientes.</p>
                </div>
            </div>
            <div class="col-lg-6 cd-md-4 col-xs-8 derechaUs">
                <div class="primerZep">
                    <img class="ourship" src="<?php echo get_template_directory_uri()?>/img/ourcompany.jpg">
                </div>
                <div class="objetivos">
                    <h1>¿Nuestros objetivos?</h1>
                    <p>Nuestro objetivo es elevarnos como un zepelin, crecer tanto como empresa como personas para poder llevar nuestros servicios al mayor numero de personas posibles.</p>
                </div>
                <div class="tercerZep">
                    <img class="ourship" src="<?php echo get_template_directory_uri()?>/img/ourcompany3.jpg">
                </div>
            </div>
        </div>
    </div>
</body>
<?php get_footer();?>