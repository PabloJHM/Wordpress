<?php  get_header();
global $wp_query;
$total_results=$wp_query->found_posts;
$encontrados=array();

//Guardamos los datos que obtenemos por GET
$recogedatos=$_GET['s']; 
//Cambiamos los separadores por espacios en blanco (NOTA: Aunque por get aparezca un '+' realmente el string está separado por espacios)
$recogedatos=limpiaArrays($recogedatos);
//Separamos el string en un array que contiene las palabras a buscar
$palabras_a_buscar=explode(' ',$recogedatos); 
//Guardamos la query que genera wordpress por defecto
$autoquery=$GLOBALS['wp_query']->request;
//echo $autoquery.'<br/>';

//Solo entra aqui si lo único seleccionado es Todo
if(isset($_GET['todo']) && !isset($_GET['post']) && !isset($_GET['categoria']) && !isset($_GET['autor'])){
    $puntoAnadir=strpos($autoquery,'WHERE 1=1');
    $autoquery=substr_replace($autoquery, ' INNER JOIN wp_term_relationships as tr on wp_posts.ID=tr.object_id
                INNER JOIN wp_terms as t on tr.term_taxonomy_id=t.term_id ', $puntoAnadir,0);
    $puntoAnadir=strpos($autoquery,')))')+2;
    foreach($palabras_a_buscar as $aux){
        $user=get_user_by('slug', $aux);
        if(get_user_by('slug', $aux)){
            $anadido.=' OR ((t.name LIKE \'%'.$aux.'%\') OR (wp_posts.post_author='.$user->ID.'))';
        } else {
            $anadido.= ' OR (t.name LIKE \'%'.$aux.'%\')';
        }
    }
    $autoquery=substr_replace($autoquery, $anadido, $puntoAnadir,0);

}

//Solo entra aqui si lo único seleccionado es categoria
if(!isset($_GET['todo']) && !isset($_GET['post']) && isset($_GET['categoria']) && !isset($_GET['autor'])){
    $cont=0;
    $autoquery="SELECT DISTINCT wp_post.ID FROM wp_posts as p 
                INNER JOIN wp_term_relationships as tr on p.ID=tr.object_id
                INNER JOIN wp_terms as t on tr.term_taxonomy_id=t.term_id";
    foreach($palabras_a_buscar as $aux){
        if($cont>0){
            $autoquery.=" OR t.name LIKE '%".$aux."%'";
        }else{
            $autoquery.=" WHERE t.name LIKE '%".$aux."%'";
        }
        $cont++;
    }
}

//Solo entra aqui si lo único seleccionado es autor
// AVISO: Por alguna razon ajena a mi entendimiento, los posts creados por el administrador no aparecen al buscarse, no obstante no hay ningun otro problema con cualquier otro tipo de usuario, solo da problemas con el administrador. He estado investigando y debe ser un error de wordpress, puesto que no hay diferencia en las bases de datos entre el admin y otro usuario, por lo que no he conseguido arreglar el problema.
if(!isset($_GET['todo']) && !isset($_GET['post']) && !isset($_GET['categoria']) && isset($_GET['autor'])){
    foreach($palabras_a_buscar as $aux){
        if(get_user_by('slug', $aux)){
            $user=get_user_by('slug', $aux);
            $autoquery=preg_replace('/post\_title LIKE/','post_author=',$autoquery); 
            $autoquery=preg_replace('/post\_content LIKE/','post_author=',$autoquery); 
            $autoquery=preg_replace('/\'\%'.$aux.'\%\'/',$user->ID,$autoquery); 
        }
    } 
}
//Modificamos la query con preg_replace para modificar 'AND' por 'OR' para que recoja correctamente los post
$myquery=preg_replace('/\)\) AND \(\(/',')) OR ((',$autoquery);
$myquery=preg_replace('/SQL\_CALC\_FOUND\_ROWS/','DISTINCT',$myquery);
//Asignamos la query modificada

$post_id=$wpdb->get_col($myquery);
$args=array(
    'showposts'=>30,
    'post__in'=>$post_id,
);
$the_query=new WP_Query($args);
?>
<div class="container">
    <div class="resultados">
        <h3>Busqueda</h3>
    <?php
        get_template_part('searchavanzado');
    //    echo  $_SERVER['HTTP_REFERER'];
        //Loop personalizado
        if($the_query->have_posts()):
            while($the_query->have_posts()):
                $the_query->the_post();
                $number_of_posts = (have_posts()) ? sizeof($wp_query->posts) : 0;
                if($number_of_posts>0){
                    get_template_part('content',get_post_format());
                } else {
                    $zero=true;
                }
            endwhile;
        endif;
    wp_reset_query();
        if($zero==true){?>
            <p>Lo siento, no se encontraron resultados de <?php foreach($palabras_a_buscar as $aux){echo '<b>'.$aux.'</b>'.', ';}?> compruebe que esten bien escritas las palabras y estás buscando en el apartado correcto (Si no está seguro del apartado, busque en "Todo")</p>
    <?php }?>
    </div>
</div>
<?php get_footer();?>