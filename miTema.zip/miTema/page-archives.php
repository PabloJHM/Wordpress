<?php 
    /*Template Name: Archives*/
    /*Se llama page-archives porque por algun motivo en mi ordenador no reconoce "archives.php", asi que miré en el mapa de paginas de wp y vi que esta era una de las que comprueba antes de mostrar el index, y parece ser que con esta si funciona*/
    get_header();?>
<body>
    <div class="container">
        <div class="col-lg-4 cd-md-4 col-xs-8 izquierda">
            <h2>Posts</h2>
                        <!-- para visualizar una lista de los archivos ordenados por año y cuantos hay de ese año:-->
            <p>Por fecha:</p>
            <?php wp_get_archives('type=yearly&show_post_count=1'); ?>
            <hr>
            <?php wp_get_archives('type=monthly&show_post_count=1'); ?>
            <hr>
            <?php wp_get_archives('type=daily&show_post_count=1'); ?>
            <hr>
            <p>Por categorias:</p>
            
            <?php 
            $args = array(
	                    
                        'title_li' => '',
                );?>
            
            <ul class="bycategories">
                <?php wp_list_categories($args);?>
            </ul>
            <div class="clear"></div>
            <?php get_the_tag_list(' ', ' ', ' ');?>
        </div>  
        <div class="col-lg-4 cd-md-4 col-xs-8 centro">
            <h2>Explorar</h2>
            <?php get_search_form();?>
            <p>Nuestros autores: </p>
            <?php wp_list_authors('show_fullname=1&optioncount=1&hide_empty=0');?>
        </div>  
        <div class="col-lg-4 cd-md-4 col-xs-8 derecha">
            <h2>Actividades recientes</h2>
            <?php get_sidebar('archives'); ?>
        </div>  
    </div>
<?php get_footer();?>