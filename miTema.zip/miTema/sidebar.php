<div class="sidebarra">
    <section class="buscar">
        <?php get_search_form();?>
    </section>

    <section class="tagcloud">
<!--
        <z?php 
        $args=array('smallest'=>10,'largest'=>20,'unit'=>'pt','orderby'=>'name');
        wp_tag_cloud($args); ?>
-->
        <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Widgets')) :?>
        <!-- Lo que haya aquí se mostrará en caso de que no existan widgets. En caso de que existan widgets, utilizarán este espacio -->
        Hola
        <?php endif?>
    </section>

    <section class="lastsPosts">
        <h2>Ultimas entradas</h2>
        <?php 
            wp_get_archives(array(
                'type'=>'postbypost',
                'limit'=>3,
                'format'=>'html',
                'show_post:count'=>false,
                'echo'=>1
            ));
        ?>
    </section>

    <section class="paginas">
        <h2>Paginas</h2>
        <ul class="black">
            <?php wp_list_pages('title_li='); ?>
        </ul>
    </section>

    <section class="categorias">
        <h2>Categorias</h2>
        <ul>
            <?php wp_list_categories('title_li='); ?>
        </ul>
    </section>
    
    <section class="autores">
        <h2>Listado de autores</h2>
        <div class="sideaut">
            <?php wp_list_authors('show_fullname=1&optioncount=0&hide_empty=0');?>
        </div>
    </section>
</div>