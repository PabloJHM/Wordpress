<?php get_header();?>
<body>
    <div class="container">
        <div class="error404">
            <img class="img404" src="<?php echo get_template_directory_uri()?>/img/404.png">  
            <h2>Oops, página no encontrada</h2><br>
            <h4>Puede volver a <a href="http://localhost:8080/blog/">Home</a> o a la pagina que estaba <a href="<?php echo $_SERVER['HTTP_REFERER'];?>">anteriormente</a></h4>
            <br>
            <?php get_search_form();?>
        </div>
    </div>
</body>
<?php get_footer();?>
